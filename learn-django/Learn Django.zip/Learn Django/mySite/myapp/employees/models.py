from django.db import models

# Create your models here.

class Employee(models.Model):

    GENDER_CHOICES = {
        ('M', 'male'),
        ('F', 'female'),
        ('O', 'Other')
    }

    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50, blank=True)
    email_id = models.EmailField(max_length=255)
    phone = models.CharField(max_length=13)
    employee_gender = models.CharField(choices=GENDER_CHOICES, max_length=1)
    employee_address = models.TextField()
    employee_job = models.ManyToManyField("availableJobs", blank=True)
    date_of_birth = models.DateField()

class availableJobs(models.Model):
    name = models.CharField(max_length=100)
